require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json());

app.get("/api/health", (req, res) => res.json({ ok: true }));

app.use("/api/auth", require("./src/routes/auth"));
app.use("/api/cases", require("./src/routes/cases"));
app.use("/api/users", require("./src/routes/users"));

// จับ error ที่หลุดมาโดยไม่คาดคิด กันไม่ให้ server ล่มทั้งตัวและกันไม่ให้ stack trace หลุดไปหาผู้ใช้
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "เกิดข้อผิดพลาดที่ไม่คาดคิดในระบบ" });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`✅ API server กำลังทำงานที่พอร์ต ${PORT}`));
