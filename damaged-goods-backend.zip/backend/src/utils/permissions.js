// ตรรกะสิทธิ์การใช้งาน — เป็นแหล่งความจริงเดียว (single source of truth) ฝั่งเซิร์ฟเวอร์
// พอร์ตมาจากฟังก์ชัน can() ในหน้าเว็บ frontend ให้ตรงกันทุกจุด
// ต่างจากเวอร์ชัน client-only ตรงที่ตรงนี้ "บังคับใช้จริง" ไม่มีทางถูกข้ามผ่าน dev tools หรือแก้ URL ได้

const DEPT_VALUES = ["Inbound", "Outbound", "Inventory", "ตรวจปล่อย"];
const ROLE_VALUES = ["staff", "dept_supervisor", "supervisor", "admin"];
const STATUS_VALUES = ["New", "In Progress", "Pending", "Resolved", "Closed"];

/**
 * @param {string} action - 'view' | 'create' | 'edit' | 'status' | 'delete' | 'manageUsers' | 'grantAdmin'
 * @param {object} user - { id, username, display_name/displayName, role, department }
 * @param {object|null} caseRow - แถวเคสจากฐานข้อมูล (จำเป็นสำหรับ 'edit' และ 'status')
 */
function can(action, user, caseRow) {
  if (!user) return false;
  const r = user.role;
  const displayName = user.display_name || user.displayName;

  switch (action) {
    case "view":
      return true; // การมองเห็นจริงถูกจำกัดที่ระดับ query (ดู scopeWhereClause) ไม่ใช่ตรงนี้
    case "create":
      return true; // staff, dept_supervisor, supervisor, admin สร้างเคสได้ทุกคน
    case "edit":
    case "status":
      if (r === "admin" || r === "supervisor") return true;
      if (r === "dept_supervisor") return !!caseRow && caseRow.department === user.department;
      if (r === "staff") return !!caseRow && caseRow.creator_name === displayName;
      return false;
    case "delete":
      return r === "admin" || r === "supervisor";
    case "manageUsers":
      return r === "admin" || r === "supervisor";
    case "grantAdmin":
      // เฉพาะ Admin เท่านั้นที่ตั้งค่าหรือแก้ไขบัญชีที่มีบทบาท Admin ได้
      return r === "admin";
    default:
      return false;
  }
}

// ข้อความปฏิเสธที่สอดคล้องกับเหตุผลของแต่ละบทบาท (ใช้ให้ตรงกับข้อความฝั่ง frontend)
function denialMessage(user) {
  if (user.role === "dept_supervisor") return "จัดการได้เฉพาะเคสในแผนกของคุณเท่านั้น";
  if (user.role === "staff") return "แก้ไขได้เฉพาะเคสที่คุณสร้างเท่านั้น";
  return "คุณไม่มีสิทธิ์ทำรายการนี้";
}

module.exports = { can, denialMessage, DEPT_VALUES, ROLE_VALUES, STATUS_VALUES };
