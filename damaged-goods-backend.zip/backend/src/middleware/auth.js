const jwt = require("jsonwebtoken");
const { can, denialMessage } = require("../utils/permissions");

// ตรวจสอบว่าคำขอนี้แนบ token ที่ถูกต้องมาหรือไม่ ทุก endpoint ที่ต้องล็อกอินต้องผ่านตัวนี้ก่อน
function authenticate(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: "ไม่พบ token กรุณาเข้าสู่ระบบใหม่" });
  }
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { id, username, display_name, role, department }
    next();
  } catch (e) {
    return res.status(401).json({ error: "token ไม่ถูกต้องหรือหมดอายุ กรุณาเข้าสู่ระบบใหม่" });
  }
}

// ตรวจสิทธิ์แบบไม่ผูกกับเคสใดเคสหนึ่ง (เช่น 'create', 'delete', 'manageUsers')
// ต้องเรียกหลัง authenticate เสมอ
function requirePermission(action) {
  return (req, res, next) => {
    if (!can(action, req.user)) {
      return res.status(403).json({ error: denialMessage(req.user) });
    }
    next();
  };
}

module.exports = { authenticate, requirePermission };
