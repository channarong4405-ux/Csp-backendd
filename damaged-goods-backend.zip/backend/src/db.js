const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // ปรับ max ตามขนาดทีมจริง; ค่านี้เพียงพอสำหรับผู้ใช้งานหลักสิบ-ร้อยคนพร้อมกัน
  max: 10,
  idleTimeoutMillis: 30000,
});

pool.on("error", (err) => {
  console.error("Unexpected PostgreSQL pool error:", err);
});

module.exports = pool;
