const express = require("express");
const pool = require("../db");
const { authenticate, requirePermission } = require("../middleware/auth");
const { can, denialMessage, STATUS_VALUES } = require("../utils/permissions");

const router = express.Router();
router.use(authenticate);

async function getCaseOr404(id, res) {
  const result = await pool.query("SELECT * FROM cases WHERE id = $1", [id]);
  if (result.rows.length === 0) {
    res.status(404).json({ error: "ไม่พบเคสนี้" });
    return null;
  }
  return result.rows[0];
}

// GET /api/cases
// สำคัญ: การจำกัดขอบเขตตามแผนกของ dept_supervisor เกิดขึ้น "ในคำสั่ง SQL" ไม่ใช่กรองทีหลังใน JS —
// แปลว่าข้อมูลแผนกอื่นจะไม่ถูกส่งออกจากฐานข้อมูลมาที่ตัวเซิร์ฟเวอร์เลยด้วยซ้ำ ไม่ต้องพึ่งการกรองฝั่ง client
router.get("/", async (req, res) => {
  try {
    const { status, department, creator, year, code, text, page = 1, pageSize = 20 } = req.query;
    const params = [];
    const where = ["1=1"];

    if (req.user.role === "dept_supervisor") {
      params.push(req.user.department);
      where.push(`department = $${params.length}`);
    }
    if (status && status !== "all") {
      params.push(status);
      where.push(`status = $${params.length}`);
    }
    if (department) {
      params.push(department);
      where.push(`department = $${params.length}`);
    }
    if (creator) {
      params.push(creator);
      where.push(`creator_name = $${params.length}`);
    }
    if (year) {
      params.push(Number(year));
      where.push(`EXTRACT(YEAR FROM created_at) = $${params.length}`);
    }
    if (code) {
      params.push(`%${code}%`);
      where.push(`(mc ILIKE $${params.length} OR io ILIKE $${params.length} OR csp ILIKE $${params.length} OR store ILIKE $${params.length})`);
    }
    if (text) {
      params.push(`%${text}%`);
      where.push(`details ILIKE $${params.length}`);
    }

    const whereSql = where.join(" AND ");
    const countRes = await pool.query(`SELECT COUNT(*)::int AS n FROM cases WHERE ${whereSql}`, params);

    const limit = Math.min(Number(pageSize) || 20, 200); // กันคนขอทีเดียวหลักแสนแถว
    const offset = (Math.max(Number(page), 1) - 1) * limit;
    const dataParams = [...params, limit, offset];
    const dataRes = await pool.query(
      `SELECT * FROM cases WHERE ${whereSql} ORDER BY created_at DESC LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
      dataParams
    );

    res.json({ total: countRes.rows[0].n, items: dataRes.rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถดึงข้อมูลเคสได้" });
  }
});

// GET /api/cases/summary — ตัวเลขสรุปสถานะสำหรับแท็บด้านบน (ขอบเขตตามแผนกเช่นเดียวกับด้านบน)
router.get("/summary", async (req, res) => {
  try {
    const params = [];
    let where = "1=1";
    if (req.user.role === "dept_supervisor") {
      params.push(req.user.department);
      where = `department = $1`;
    }
    const result = await pool.query(
      `SELECT status, COUNT(*)::int AS n FROM cases WHERE ${where} GROUP BY status`,
      params
    );
    const counts = { all: 0 };
    STATUS_VALUES.forEach((s) => (counts[s] = 0));
    result.rows.forEach((r) => {
      counts[r.status] = r.n;
      counts.all += r.n;
    });
    res.json(counts);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถดึงข้อมูลสรุปได้" });
  }
});

router.get("/:id/history", async (req, res) => {
  try {
    const caseRow = await getCaseOr404(req.params.id, res);
    if (!caseRow) return;
    if (req.user.role === "dept_supervisor" && caseRow.department !== req.user.department) {
      return res.status(403).json({ error: denialMessage(req.user) });
    }
    const hist = await pool.query("SELECT * FROM case_history WHERE case_id = $1 ORDER BY created_at ASC", [req.params.id]);
    res.json(hist.rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถดึงประวัติได้" });
  }
});

router.post("/", requirePermission("create"), async (req, res) => {
  try {
    const { store, mc, io, csp, cspUrl, department, details } = req.body;
    if (!store || !mc || !io || !csp || !department || !details) {
      return res.status(400).json({ error: "กรุณากรอกข้อมูลให้ครบทุกช่อง" });
    }
    // dept_supervisor สร้างเคสได้เฉพาะแผนกของตัวเองเท่านั้น แม้ว่า client จะส่งแผนกอื่นมาก็ตาม
    const finalDept = req.user.role === "dept_supervisor" ? req.user.department : department;

    const caseCode = "CASE-" + Date.now();
    const insertRes = await pool.query(
      `INSERT INTO cases (case_code, store, mc, io, csp, csp_url, department, creator_id, creator_name, details, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'New')
       RETURNING *`,
      [caseCode, store, mc, io, csp, cspUrl || null, finalDept, req.user.id, req.user.display_name, details]
    );
    const newCase = insertRes.rows[0];

    await pool.query(
      `INSERT INTO case_history (case_id, who, event_type, detail, old_status, new_status)
       VALUES ($1,$2,'create',$3,NULL,'New')`,
      [newCase.id, req.user.display_name, JSON.stringify({ note: "สร้างเคสใหม่" })]
    );

    res.status(201).json(newCase);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถสร้างเคสได้" });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const caseRow = await getCaseOr404(req.params.id, res);
    if (!caseRow) return;
    if (!can("edit", req.user, caseRow)) {
      return res.status(403).json({ error: denialMessage(req.user) });
    }

    const { store, mc, io, csp, cspUrl, department, details } = req.body;
    // dept_supervisor ย้ายเคสออกนอกแผนกตัวเองไม่ได้ แม้จะพยายามส่งค่ามาก็ตาม
    const finalDept = req.user.role === "dept_supervisor" ? caseRow.department : department;

    const candidates = [
      ["store", store, caseRow.store],
      ["mc", mc, caseRow.mc],
      ["io", io, caseRow.io],
      ["csp", csp, caseRow.csp],
      ["csp_url", cspUrl, caseRow.csp_url],
      ["department", finalDept, caseRow.department],
      ["details", details, caseRow.details],
    ];
    const changed = candidates.filter(([, newVal, oldVal]) => (newVal ?? "") !== (oldVal ?? "") && newVal !== undefined);
    if (changed.length === 0) return res.json(caseRow);

    const setSql = changed.map(([k], i) => `${k} = $${i + 1}`).join(", ");
    const values = changed.map(([, v]) => v);
    values.push(req.params.id);
    const updateRes = await pool.query(`UPDATE cases SET ${setSql} WHERE id = $${values.length} RETURNING *`, values);

    await pool.query(
      `INSERT INTO case_history (case_id, who, event_type, detail, old_status, new_status)
       VALUES ($1,$2,'edit',$3,$4,$4)`,
      [
        req.params.id,
        req.user.display_name,
        JSON.stringify(changed.map(([k, v, old]) => ({ field: k, old, new: v }))),
        caseRow.status,
      ]
    );

    res.json(updateRes.rows[0]);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถบันทึกการแก้ไขได้" });
  }
});

router.patch("/:id/status", async (req, res) => {
  try {
    const caseRow = await getCaseOr404(req.params.id, res);
    if (!caseRow) return;
    if (!can("status", req.user, caseRow)) {
      return res.status(403).json({ error: denialMessage(req.user) });
    }
    const { status } = req.body;
    if (!STATUS_VALUES.includes(status)) {
      return res.status(400).json({ error: "สถานะไม่ถูกต้อง" });
    }
    if (status === caseRow.status) return res.json(caseRow);

    const updateRes = await pool.query("UPDATE cases SET status = $1 WHERE id = $2 RETURNING *", [status, req.params.id]);
    await pool.query(
      `INSERT INTO case_history (case_id, who, event_type, detail, old_status, new_status)
       VALUES ($1,$2,'status',$3,$4,$5)`,
      [
        req.params.id,
        req.user.display_name,
        JSON.stringify({ note: `เปลี่ยนสถานะจาก ${caseRow.status} เป็น ${status}` }),
        caseRow.status,
        status,
      ]
    );

    res.json(updateRes.rows[0]);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถเปลี่ยนสถานะได้" });
  }
});

// DELETE /api/cases  body: { ids: [1,2,3] } — ลบหลายรายการพร้อมกัน (เฉพาะ admin / supervisor)
router.delete("/", requirePermission("delete"), async (req, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: "ไม่พบรายการที่เลือกสำหรับลบ" });
    }
    const numericIds = ids.map(Number).filter((n) => Number.isInteger(n));
    const result = await pool.query("DELETE FROM cases WHERE id = ANY($1::int[]) RETURNING id", [numericIds]);
    res.json({ deleted: result.rows.length });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถลบรายการได้" });
  }
});

module.exports = router;
