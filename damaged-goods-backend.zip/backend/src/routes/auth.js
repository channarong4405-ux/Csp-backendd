const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const pool = require("../db");

const router = express.Router();
const SALT_ROUNDS = 12;

function signToken(user) {
  return jwt.sign(
    {
      id: user.id,
      username: user.username,
      display_name: user.display_name,
      role: user.role,
      department: user.department,
    },
    process.env.JWT_SECRET,
    { expiresIn: "12h" }
  );
}

function sanitizeUser(u) {
  return {
    id: u.id,
    username: u.username,
    displayName: u.display_name,
    role: u.role,
    department: u.department,
  };
}

// สมัครบัญชีสาธารณะ — เริ่มต้นเป็น 'staff' เสมอ (ยกเว้นเป็นผู้ใช้คนแรกของระบบ = admin โดยอัตโนมัติ)
// การกำหนดบทบาทอื่น (dept_supervisor / supervisor / admin) ทำได้เฉพาะผ่าน POST /api/users โดยผู้มีสิทธิ์ manageUsers เท่านั้น
router.post("/register", async (req, res) => {
  try {
    const { username, displayName, password } = req.body;
    if (!username || !displayName || !password) {
      return res.status(400).json({ error: "กรุณากรอกข้อมูลให้ครบทุกช่อง" });
    }
    if (password.length < 4) {
      return res.status(400).json({ error: "รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร" });
    }

    const existing = await pool.query("SELECT id FROM users WHERE LOWER(username) = LOWER($1)", [username]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: "มีชื่อผู้ใช้นี้อยู่แล้ว กรุณาใช้ชื่ออื่น" });
    }

    const countRes = await pool.query("SELECT COUNT(*)::int AS n FROM users");
    const role = countRes.rows[0].n === 0 ? "admin" : "staff";
    const hash = await bcrypt.hash(password, SALT_ROUNDS);

    const insertRes = await pool.query(
      `INSERT INTO users (username, display_name, password_hash, role, department)
       VALUES ($1, $2, $3, $4, NULL)
       RETURNING id, username, display_name, role, department`,
      [username, displayName, hash, role]
    );
    const user = insertRes.rows[0];
    res.status(201).json({ token: signToken(user), user: sanitizeUser(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "เกิดข้อผิดพลาดในการสร้างบัญชี" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: "กรุณากรอกชื่อผู้ใช้และรหัสผ่าน" });
    }
    const result = await pool.query("SELECT * FROM users WHERE LOWER(username) = LOWER($1)", [username]);
    const user = result.rows[0];
    // ข้อความเดียวกันไม่ว่าจะ "ไม่พบผู้ใช้" หรือ "รหัสผ่านผิด" ป้องกันการเดาว่ามีบัญชีนี้อยู่จริงหรือไม่
    if (!user) return res.status(401).json({ error: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });

    res.json({ token: signToken(user), user: sanitizeUser(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "เกิดข้อผิดพลาดในการเข้าสู่ระบบ" });
  }
});

module.exports = router;
