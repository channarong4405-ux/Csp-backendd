const express = require("express");
const bcrypt = require("bcrypt");
const pool = require("../db");
const { authenticate, requirePermission } = require("../middleware/auth");
const { DEPT_VALUES, ROLE_VALUES } = require("../utils/permissions");

const router = express.Router();
router.use(authenticate);
router.use(requirePermission("manageUsers")); // ทุก endpoint ในไฟล์นี้ต้องเป็น admin หรือ supervisor เท่านั้น

function sanitize(u) {
  return {
    id: u.id,
    username: u.username,
    displayName: u.display_name,
    role: u.role,
    department: u.department,
    createdAt: u.created_at,
  };
}

router.get("/", async (req, res) => {
  const result = await pool.query(
    "SELECT id, username, display_name, role, department, created_at FROM users ORDER BY created_at ASC"
  );
  res.json(result.rows.map(sanitize));
});

router.post("/", async (req, res) => {
  try {
    const { username, displayName, password, role, department } = req.body;
    if (!username || !displayName || !password || !role) {
      return res.status(400).json({ error: "กรุณากรอกข้อมูลให้ครบทุกช่อง" });
    }
    if (!ROLE_VALUES.includes(role)) {
      return res.status(400).json({ error: "บทบาทไม่ถูกต้อง" });
    }
    // เฉพาะ Admin ตัวจริงเท่านั้นที่ตั้งบัญชีใหม่เป็น Admin ได้ — Supervisor ทำไม่ได้แม้เข้าเมนูนี้ได้ก็ตาม
    if (role === "admin" && req.user.role !== "admin") {
      return res.status(403).json({ error: "เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถกำหนดบทบาทผู้ดูแลระบบได้" });
    }
    if (password.length < 4) {
      return res.status(400).json({ error: "รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร" });
    }
    if (role === "dept_supervisor" && !DEPT_VALUES.includes(department)) {
      return res.status(400).json({ error: "กรุณาเลือกแผนกที่ถูกต้อง" });
    }

    const existing = await pool.query("SELECT id FROM users WHERE LOWER(username) = LOWER($1)", [username]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: "มีชื่อผู้ใช้นี้อยู่แล้ว กรุณาใช้ชื่ออื่น" });
    }

    const hash = await bcrypt.hash(password, 12);
    const dept = role === "dept_supervisor" ? department : null;
    const insertRes = await pool.query(
      `INSERT INTO users (username, display_name, password_hash, role, department)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING id, username, display_name, role, department, created_at`,
      [username, displayName, hash, role, dept]
    );
    res.status(201).json(sanitize(insertRes.rows[0]));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถเพิ่มบัญชีผู้ใช้งานได้" });
  }
});

// แก้ไขบทบาท/แผนกของผู้ใช้ — ป้องกันการเปลี่ยนสิทธิ์ตัวเอง และป้องกันคนที่ไม่ใช่ admin แตะบัญชี admin
router.patch("/:id", async (req, res) => {
  try {
    const targetId = Number(req.params.id);
    if (targetId === req.user.id) {
      return res.status(403).json({ error: "ไม่สามารถเปลี่ยนสิทธิ์ของบัญชีตนเองได้" });
    }

    const targetRes = await pool.query("SELECT * FROM users WHERE id = $1", [targetId]);
    const target = targetRes.rows[0];
    if (!target) return res.status(404).json({ error: "ไม่พบผู้ใช้งานนี้" });

    if (target.role === "admin" && req.user.role !== "admin") {
      return res.status(403).json({ error: "เฉพาะผู้ดูแลระบบเท่านั้นที่แก้ไขบัญชีผู้ดูแลระบบด้วยกันได้" });
    }

    const { role, department } = req.body;
    if (role && !ROLE_VALUES.includes(role)) {
      return res.status(400).json({ error: "บทบาทไม่ถูกต้อง" });
    }
    if (role === "admin" && req.user.role !== "admin") {
      return res.status(403).json({ error: "เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถกำหนดบทบาทผู้ดูแลระบบได้" });
    }

    const finalRole = role || target.role;
    let finalDept = target.department;
    if (finalRole === "dept_supervisor") {
      finalDept = department && DEPT_VALUES.includes(department) ? department : target.department || "Outbound";
    } else {
      finalDept = null;
    }

    const updateRes = await pool.query(
      `UPDATE users SET role = $1, department = $2 WHERE id = $3
       RETURNING id, username, display_name, role, department, created_at`,
      [finalRole, finalDept, targetId]
    );
    res.json(sanitize(updateRes.rows[0]));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "ไม่สามารถอัปเดตบัญชีผู้ใช้งานได้" });
  }
});

module.exports = router;
