# Backend — ระบบบันทึกการสร้างตั๋ว CSP - SW

API server จริงสำหรับแทนที่ระบบเดิมที่เก็บข้อมูลไว้ใน `window.storage` ของ Claude
บังคับสิทธิ์ตาม role/department **ที่ตัวเซิร์ฟเวอร์เอง** ไม่ใช่แค่ที่หน้าเว็บ — จุดนี้คือสิ่งที่
ทำให้ใช้งานจริงในองค์กรได้อย่างปลอดภัย (กันการเข้าถึงผ่าน URL หรือ dev tools ตรงๆ)

## สิ่งที่ต้องมีก่อนเริ่ม

- Node.js เวอร์ชัน 18 ขึ้นไป
- PostgreSQL เวอร์ชัน 13 ขึ้นไป (ติดตั้งเองบนเซิร์ฟเวอร์ หรือใช้บริการเช่น Amazon RDS, Neon, Railway Postgres)
- เซิร์ฟเวอร์/VM หนึ่งเครื่องที่มีคนดูแล (VPS เช่น DigitalOcean, Vultr, AWS EC2 หรือจะใช้ PaaS อย่าง Render/Railway ก็ได้เพื่อลดงาน ops)

## ขั้นตอนติดตั้งครั้งแรก

```bash
# 1. สร้างฐานข้อมูลเปล่าบน PostgreSQL
createdb damaged_goods

# 2. รัน schema
psql -U <user> -d damaged_goods -f schema.sql

# 3. ติดตั้ง dependencies
npm install

# 4. ตั้งค่า environment variables
cp .env.example .env
# แก้ DATABASE_URL, JWT_SECRET (สุ่มด้วย: openssl rand -hex 32), CORS_ORIGIN ให้ตรงจริง

# 5. รันเซิร์ฟเวอร์
npm start
```

ทดสอบว่าเซิร์ฟเวอร์ทำงาน: `curl http://localhost:4000/api/health` ควรได้ `{"ok":true}`

## สร้างบัญชีแรก (Admin)

ผู้ใช้คนแรกที่สมัครผ่าน `POST /api/auth/register` จะได้บทบาท `admin` โดยอัตโนมัติเสมอ
(เช็คจากจำนวนแถวในตาราง `users` ตอนนั้น — ถ้ายังไม่มีใครเลยคนแรกจะเป็น admin)
หลังจากนั้นให้ admin คนนี้ใช้ `POST /api/users` เพื่อสร้างบัญชีอื่นพร้อมกำหนดบทบาทได้เลย

## รายการ API หลัก

| Method | Endpoint | สิทธิ์ | คำอธิบาย |
|---|---|---|---|
| POST | `/api/auth/register` | สาธารณะ | สมัครบัญชีใหม่ (เริ่มต้นเป็น staff) |
| POST | `/api/auth/login` | สาธารณะ | เข้าสู่ระบบ ได้ JWT token กลับมา |
| GET | `/api/cases` | ต้องล็อกอิน | ดูรายการเคส (กรองตามแผนกอัตโนมัติถ้าเป็น dept_supervisor) |
| GET | `/api/cases/summary` | ต้องล็อกอิน | ตัวเลขสรุปตามสถานะ สำหรับแท็บด้านบน |
| GET | `/api/cases/:id/history` | ต้องล็อกอิน + อยู่ในขอบเขต | ประวัติการแก้ไขของเคสนั้น |
| POST | `/api/cases` | staff ขึ้นไป | สร้างเคสใหม่ |
| PUT | `/api/cases/:id` | ตามสิทธิ์ความเป็นเจ้าของ/แผนก | แก้ไขเคส |
| PATCH | `/api/cases/:id/status` | ตามสิทธิ์ความเป็นเจ้าของ/แผนก | เปลี่ยนสถานะ |
| DELETE | `/api/cases` (body: `{ids:[...]}`) | admin, supervisor | ลบหลายรายการพร้อมกัน |
| GET | `/api/users` | admin, supervisor | รายชื่อผู้ใช้งานทั้งหมด |
| POST | `/api/users` | admin, supervisor* | เพิ่มบัญชีใหม่พร้อมกำหนดบทบาท |
| PATCH | `/api/users/:id` | admin, supervisor* | แก้ไขบทบาท/แผนกของผู้ใช้ |

*Supervisor เข้าเมนูจัดการผู้ใช้งานได้ แต่ตั้ง/แก้บทบาทเป็น "admin" ไม่ได้ — เฉพาะ admin ตัวจริงเท่านั้น

ทุก endpoint ที่ต้องล็อกอินต้องแนบ header: `Authorization: Bearer <token>`

## เชื่อมกับหน้าเว็บ (frontend) เดิม

หน้าเว็บ HTML ที่ทำไว้ก่อนหน้านี้เรียก `window.storage.get/set` อยู่ — ต้องแก้ให้เรียก `fetch()`
ไปยัง endpoint เหล่านี้แทน เก็บ JWT token ไว้ใน memory ของหน้าเว็บ (ตัวแปร JS ธรรมดา ไม่ใช่ localStorage
เพื่อความปลอดภัยที่สูงกว่า หรือจะใช้ httpOnly cookie ก็ได้ถ้าต้องการความปลอดภัยสูงสุด)
บอกได้เลยถ้าต้องการให้ช่วยแก้โค้ด frontend ส่วนนี้ต่อ

## Deploy ขึ้นเซิร์ฟเวอร์จริง (แนวทางคร่าวๆ)

1. **เตรียมเซิร์ฟเวอร์**: ติดตั้ง Node.js, PostgreSQL (หรือชี้ไปที่ managed database)
2. **รันแอปแบบอยู่เบื้องหลังตลอดเวลา**: ใช้ [PM2](https://pm2.keymetrics.io/) — `pm2 start server.js --name csp-backend`
3. **ตั้ง reverse proxy**: ใช้ Nginx ชี้ domain มาที่พอร์ต 4000 พร้อมออก HTTPS ด้วย Let's Encrypt (`certbot`)
4. **สำรองฐานข้อมูล**: ตั้ง cron job รัน `pg_dump` เป็นประจำ (อย่างน้อยวันละครั้ง) เก็บไว้คนละที่กับเซิร์ฟเวอร์หลัก
5. **ตรวจสอบ .env**: ห้ามใช้ `JWT_SECRET` ตัวอย่างจาก `.env.example` ในการใช้งานจริงเด็ดขาด ต้องสุ่มใหม่

## ข้อจำกัดที่ควรทราบ

- โค้ดชุดนี้ยังไม่มีฟีเจอร์ "ลืมรหัสผ่าน" หรือ "เปลี่ยนรหัสผ่านตัวเอง" — เพิ่มได้ถ้าต้องการ
- ยังไม่มี rate limiting ป้องกันการสุ่มรหัสผ่าน (brute force) แนะนำให้เพิ่ม `express-rate-limit` ก่อนใช้งานจริง
- JWT token หมดอายุใน 12 ชั่วโมง (ปรับได้ที่ `src/routes/auth.js`) — ยังไม่มีระบบ refresh token
