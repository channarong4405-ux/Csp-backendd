-- ระบบบันทึกการสร้างตั๋ว CSP - SW : Database Schema (PostgreSQL)
-- รันไฟล์นี้ครั้งเดียวตอนตั้งฐานข้อมูลใหม่: psql -U <user> -d <db> -f schema.sql

CREATE TABLE IF NOT EXISTS users (
  id             SERIAL PRIMARY KEY,
  username       VARCHAR(50) UNIQUE NOT NULL,
  display_name   VARCHAR(100) NOT NULL,
  password_hash  TEXT NOT NULL,
  role           VARCHAR(20) NOT NULL CHECK (role IN ('staff','dept_supervisor','supervisor','admin')),
  department     VARCHAR(30), -- ใช้เฉพาะเมื่อ role = dept_supervisor (Inbound / Outbound / Inventory / ตรวจปล่อย)
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cases (
  id            SERIAL PRIMARY KEY,
  case_code     VARCHAR(30) UNIQUE NOT NULL,
  store         VARCHAR(100) NOT NULL,
  mc            VARCHAR(50) NOT NULL,
  io            VARCHAR(50) NOT NULL,
  csp           VARCHAR(50) NOT NULL,
  csp_url       TEXT,
  department    VARCHAR(30) NOT NULL CHECK (department IN ('Inbound','Outbound','Inventory','ตรวจปล่อย')),
  creator_id    INTEGER NOT NULL REFERENCES users(id),
  creator_name  VARCHAR(100) NOT NULL,   -- เก็บชื่อที่แสดง ณ เวลาที่สร้าง กันปัญหาถ้าชื่อผู้ใช้ถูกแก้ไขภายหลัง
  details       TEXT NOT NULL,
  status        VARCHAR(20) NOT NULL DEFAULT 'New' CHECK (status IN ('New','In Progress','Pending','Resolved','Closed')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS case_history (
  id          SERIAL PRIMARY KEY,
  case_id     INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  who         VARCHAR(100) NOT NULL,
  event_type  VARCHAR(20) NOT NULL, -- create / edit / status
  detail      JSONB NOT NULL,       -- รายละเอียดการเปลี่ยนแปลง (field เดิม/ใหม่ หรือข้อความ)
  old_status  VARCHAR(20),
  new_status  VARCHAR(20),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_cases_department  ON cases(department);
CREATE INDEX IF NOT EXISTS idx_cases_status      ON cases(status);
CREATE INDEX IF NOT EXISTS idx_cases_created_at  ON cases(created_at);
CREATE INDEX IF NOT EXISTS idx_history_case_id   ON case_history(case_id);
